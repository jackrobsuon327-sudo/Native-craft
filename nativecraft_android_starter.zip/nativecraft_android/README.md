# NativeCraft Android — starter scaffold

This is an initial Android NDK scaffold for a native-first Minecraft Java-compatible runtime.

## Language target
- 90% C++20: core engine, platform abstraction, rendering, world/chunk systems, networking adapters.
- 9.8% C++23: isolated modern utility/performance modules where supported by the selected Android NDK.
- 0.2% Java: Android Activity/bootstrap and JNI entry point.

These percentages are project goals, not a guarantee about compiled binary size or exact line counts.

## Important compatibility note
Running the existing Minecraft Java Edition unchanged requires a JVM and substantial Java-side game code. Keeping Java to 0.2% means this project must progressively implement a native-compatible engine rather than simply run the original Java client. Minecraft's proprietary game code/assets are not included. Use legally obtained game files and clean-room implementations.

## Current scaffold
- Android Activity and JNI bootstrap
- CMake + Android NDK native library
- C++20 engine entry point
- C++23 optional feature translation unit
- Vulkan capability probe (no renderer yet)
- clear module boundaries for later implementation

## Build
Open this folder in Android Studio with Android SDK + NDK + CMake installed.
Use a recent NDK and Android Gradle Plugin. Vulkan is optional at runtime; the app should not assume every device supports the same Vulkan feature set.

This is a foundation only, not a playable Minecraft port yet.
