#pragma once
#include <string>

namespace nativecraft {
class Engine final {
public:
    static std::string status();
};
}
