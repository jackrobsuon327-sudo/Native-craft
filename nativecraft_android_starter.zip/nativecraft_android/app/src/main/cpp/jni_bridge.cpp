#include <jni.h>
#include <string>
#include "engine/engine.hpp"

extern "C"
JNIEXPORT jstring JNICALL
Java_dev_nativecraft_android_MainActivity_nativeGetStatus(JNIEnv* env, jclass) {
    const std::string status = nativecraft::Engine::status();
    return env->NewStringUTF(status.c_str());
}
