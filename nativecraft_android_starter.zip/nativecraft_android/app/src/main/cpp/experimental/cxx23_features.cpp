// C++23 area: keep optional experiments isolated from the C++20 core.
// This translation unit deliberately contains no required runtime functionality.
#include <version>

namespace nativecraft::experimental {
#if defined(__cpp_if_consteval)
constexpr int language_feature_level() noexcept { return 23; }
#else
constexpr int language_feature_level() noexcept { return 20; }
#endif
}
