#pragma once
namespace nativecraft::platform {
bool vulkan_available() noexcept;
}
