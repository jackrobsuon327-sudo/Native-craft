#include "vulkan_probe.hpp"
#include <vulkan/vulkan.h>

namespace nativecraft::platform {
bool vulkan_available() noexcept {
    uint32_t count = 0;
    return vkEnumerateInstanceExtensionProperties(nullptr, &count, nullptr) == VK_SUCCESS;
}
}
