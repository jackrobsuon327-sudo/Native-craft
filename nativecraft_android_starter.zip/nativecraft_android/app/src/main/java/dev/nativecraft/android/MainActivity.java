package dev.nativecraft.android;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

/**
 * Intentionally tiny Java bootstrap.
 * All engine work belongs in native C++ modules.
 */
public final class MainActivity extends Activity {
    static {
        System.loadLibrary("nativecraft");
    }

    private static native String nativeGetStatus();

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        TextView view = new TextView(this);
        view.setText(nativeGetStatus());
        view.setTextSize(16);
        view.setPadding(24, 24, 24, 24);
        setContentView(view);
    }
}
