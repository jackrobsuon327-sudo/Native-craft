#include "engine.hpp"
#include "../platform/android/vulkan_probe.hpp"

namespace nativecraft {
std::string Engine::status() {
    const auto gpu = platform::vulkan_available()
        ? "Vulkan loader available"
        : "Vulkan unavailable; renderer fallback required";
    return std::string("NativeCraft bootstrap OK\nC++20 engine active\n") + gpu +
           "\nNext: surface lifecycle + renderer";
}
}
